//
//  CalendarDataController.swift
//  iZotSnoozeTM
//
//  Created by Jasmine Som on 3/2/21.
//

import Foundation
import UIKit

class CalendarViewController : UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.isNavigationBarHidden = false
    }
}
