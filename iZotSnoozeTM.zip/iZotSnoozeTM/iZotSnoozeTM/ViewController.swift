//
//  ViewController.swift
//  iZotSnoozeTM
//
//  Created by Jasmine Som on 2/5/21.
//

import UIKit
import Charts
//import SwiftUI

class ViewController: UIViewController, ChartViewDelegate, UINavigationControllerDelegate {
    
    var lineChart = LineChartView()
    var barChart = BarChartView()
    var pieChart = PieChartView()
    // data Array -> user input [date, dayOfWeek, sleepTime, wakeTime, timeDiff in sec, mood]
    //var dataArray : [[String]] = [["0000 00 00", "", "00:00", "00:00", "0", "0"]]
    var dataArray = [[String]]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        barChart.delegate = self
        pieChart.delegate = self
        lineChart.delegate = self
        // Do any additional setup after loading the view.
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        // setting up size and fram of charts
        barChart.frame = CGRect(x:0, y:0, width: self.view.frame.size.width, height: 250)
        pieChart.frame = CGRect(x:0, y:0, width: 300, height: 250)
        lineChart.frame = CGRect(x:0, y:0, width: self.view.frame.size.width, height: 250)
        barChart.center = CGPoint(x: 207, y: 350)
        pieChart.center = CGPoint(x: 243, y: 350)
        lineChart.center = CGPoint(x: 207, y: 350)
        self.navigationController?.isNavigationBarHidden = true
        // load default graphs upon opening
        ChangeSegControl(MultipleCharts.selectedSegmentIndex)
    }
    
    
    @IBOutlet weak var AnalysisData: UILabel!
    @IBOutlet weak var TableLabel: UILabel!
    @IBOutlet weak var MultipleCharts: UISegmentedControl!
    @IBOutlet weak var TodayDate: UILabel!
    @IBOutlet weak var MoonFillerForNoData: UIImageView!
    
    // ### USER DATE ###
    // get the current date and time
    let currentDateTime = Date()
    // get the user's calendar
    let userCalendar = Calendar.current
    
    //formatting date to compare with user data
    func getuserFormattedDate() -> String{
    var currentDate = String(userCalendar.component(.year, from: currentDateTime)) + " "
    if String(userCalendar.component(.month, from: currentDateTime)).count == 1 {
        currentDate += "0" + String(userCalendar.component(.month, from: currentDateTime)) + " "
    } else {currentDate += String(userCalendar.component(.month, from: currentDateTime)) + " "}
    currentDate += String(userCalendar.component(.day, from: currentDateTime))
    return currentDate
    }
    
    
    // seg control
    @IBAction func ChangeSegControl(_ sender: Any) {
        switch MultipleCharts.selectedSegmentIndex
            {
            case 0: // "TODAY"
                // removing ad adding views
                let userCurrentDate = getuserFormattedDate()
                updateDate(label: TodayDate, s: userCurrentDate)
                barChart.removeFromSuperview()
                lineChart.removeFromSuperview()
                LabelToDailyOverview(label:TableLabel)
                removeImageView(image: MoonFillerForNoData)
                //#########################
                var entries = [ChartDataEntry]()
                let dateInArr = checkDateinArr(str: userCurrentDate, arr: dataArray)
                if dateInArr {
                    if dataArray[0][0] == userCurrentDate {
                    entries.append(ChartDataEntry(x: Double(0), y: Double(dataArray[0][4])!/60/60))
                    entries.append(ChartDataEntry(x: Double(1), y: (Double(24) - (Double(dataArray[0][4])!/60/60))))
                    
                    let set = PieChartDataSet(entries: entries)
                    set.colors = ChartColorTemplates.liberty()
                    
                    let data = PieChartData(dataSet: set)
                    pieChart.data = data
                    pieChart.data?.setValueFont(NSUIFont.systemFont(ofSize: 0))
                    pieChart.holeRadiusPercent = CGFloat(0)
                    pieChart.centerTextRadiusPercent = CGFloat(1)
                    pieChart.legend.entries = [LegendEntry(label: "SLEPT  ", form: .default, formSize: CGFloat(20), formLineWidth: CGFloat(30), formLineDashPhase: .nan, formLineDashLengths: .none, formColor: #colorLiteral(red: 0.5796257854, green: 0.8301811218, blue: 0.8309018612, alpha: 1)), LegendEntry(label: "AWAKE  ", form: .default, formSize: CGFloat(20), formLineWidth: CGFloat(30), formLineDashPhase: .nan, formLineDashLengths: .none, formColor: #colorLiteral(red: 0.812982142, green: 0.9734575152, blue: 0.9664494395, alpha: 1))]
                    pieChart.legend.yEntrySpace = CGFloat(10)
                    pieChart.legend.xEntrySpace = CGFloat(70)
                    pieChart.legend.form = Legend.Form(rawValue: 4)!
                    pieChart.legend.horizontalAlignment = Legend.HorizontalAlignment(rawValue: 0)!
                    pieChart.legend.verticalAlignment = Legend.VerticalAlignment(rawValue: 1)!
                    pieChart.legend.orientation = Legend.Orientation(rawValue: 1)!
                    pieChart.legend.textWidthMax = CGFloat(70)
                    pieChart.legend.font = NSUIFont.systemFont(ofSize: 12.0)
                    pieChart.legend.textColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
                    pieChart.transparentCircleColor = #colorLiteral(red: 0.2729828358, green: 0.3263296783, blue: 0.3689593077, alpha: 1)
                    view.addSubview(pieChart)
                    }
        } else {
            promptAnalysisForNoData(str: "T O D A Y", label: AnalysisData)
            showImageView(image: MoonFillerForNoData)
            removeLabel(label: TableLabel)
            removeLabel(label: TodayDate)
        }
 //#####################################################################################################
            case 1: // "WEEK"
                // removing and adding views
                updateTableLabel(label: TableLabel)
                removeLabel(label: TodayDate)
                pieChart.removeFromSuperview()
                lineChart.removeFromSuperview()
                removeLabel(label: AnalysisData)
                removeImageView(image: MoonFillerForNoData)
                //########################
                var entries = [BarChartDataEntry]()
                let userDayofWeek = getTodayWeekDay()
                let userCurrentDate = getuserFormattedDate()
                //let thisWeekinArr = checkDateinArr(str: userCurrentDate, arr: dataArray)
                if checkDateinArr(str: userCurrentDate, arr: dataArray) {
                    //dataArray.append([userCurrentDate, userDayofWeek, "00:00", "00:00", "0", "0"])
                    switch userDayofWeek {
                        case "Sun": addNext7DaysDefault(lstOfDays: ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat"])
                        case "Mon": addNext7DaysDefault(lstOfDays: ["Sun", "Tue", "Wed", "Thu", "Fri", "Sat"])
                        case "Tue": addNext7DaysDefault(lstOfDays: ["Mon", "Sun", "Wed", "Thu", "Fri", "Sat"])
                        case "Wed": addNext7DaysDefault(lstOfDays: ["Mon", "Tue", "Sun", "Thu", "Fri", "Sat"])
                        case "Thu": addNext7DaysDefault(lstOfDays: ["Mon", "Tue", "Wed", "Sun", "Fri", "Sat"])
                        case "Fri": addNext7DaysDefault(lstOfDays: ["Mon", "Tue", "Wed", "Thu", "Sun", "Sat"])
                        case "Sat": addNext7DaysDefault(lstOfDays: ["Mon", "Tue", "Wed", "Thu", "Fri", "Sun"])
                        default:
                            break
                    }
                    var count = 0
                    while count != 7 {
                        // need to append only the week's data
                        let userdate = reformatToDate(strDate: userCurrentDate)
                        if userdate.isInSevenDays() {
                        entries.append(BarChartDataEntry(x: Double(count), y: Double(dataArray[count][4])!/60/60))
                        count += 1
                        }
                   }
                loadBarGraph(entries: entries)
                } else {
                    promptAnalysisForNoData(str: "T H I S   W E E K", label: AnalysisData)
                    showImageView(image: MoonFillerForNoData)
                    removeLabel(label: TableLabel)
                }
//#####################################################################################################

            case 2: // "MONTH"
                // removing and adding views
                updateTableLabel(label: TableLabel)
                barChart.removeFromSuperview()
                removeLabel(label: TodayDate)
                removeLabel(label: AnalysisData)
                pieChart.removeFromSuperview()
                removeImageView(image: MoonFillerForNoData)
                //########################
                if dataArray.count != 0{
                    var entries = [ChartDataEntry]()
                    dataArray.sort{($0[0] < $1[0])}
                    // need to set x to == day of the month
                    // use calendar to sync and show based on user month
                    if dataArray.count >= 30 {
                        for i in 0..<30 {
                            entries.append(ChartDataEntry(x: Double(i), y: Double(dataArray[i][4])!/60/60))
                        }
                        loadlineGraph(entries: entries)
                    } else {
                        for i in 0..<dataArray.count {
                            entries.append(ChartDataEntry(x: Double(i), y: Double(dataArray[i][4])!/60/60))
                        }
                        loadlineGraph(entries: entries)}
                        dataArray.sort{($0[0] > $1[0])}
                        
                }else {
                    removeLabel(label: TableLabel)
                    promptAnalysisForNoData(str: "T H I S   M O N T H", label: AnalysisData)
                    showImageView(image: MoonFillerForNoData)
                }
                
//#####################################################################################################
        case 3: // "TIPS"
            removeLabel(label: TableLabel)
            removeLabel(label: TodayDate)
            pieChart.removeFromSuperview()
            lineChart.removeFromSuperview()
            barChart.removeFromSuperview()
            removeLabel(label: AnalysisData)
            removeImageView(image: MoonFillerForNoData)
        default:
            break
        }
    }
    
//#####################################################################################################

    func addNext7DaysDefault(lstOfDays: [String]){
        var count = 0
        for i in lstOfDays{
            count += 1
            var date = String(userCalendar.component(.year, from: currentDateTime)) + " "
            if String(userCalendar.component(.month, from: currentDateTime)).count == 1 {
                date += "0" + String(userCalendar.component(.month, from: currentDateTime)) + " "
            } else {date += String(userCalendar.component(.month, from: currentDateTime)) + " "}
            date += String(userCalendar.component(.day, from: currentDateTime) + count)
            let inArr = checkDateinArr(str: date, arr: dataArray)
            if inArr != true {dataArray.append([date, i, "00:00", "00:00", "0", "0"])}}
        dataArray.sort{($0[0] > $1[0])}
        print(dataArray)
    }
    
    
    // functions for reducing switch-case/seg control screen changes
    func loadlineGraph(entries: Any){
        let set = LineChartDataSet(entries: (entries as! [ChartDataEntry]), label: nil)
        set.colors = ChartColorTemplates.liberty()
        let data = LineChartData(dataSet: set)
        lineChart.data = data
        lineChart.legend.form = Legend.Form(rawValue: 0)!
        //lineChart.xAxis.gridColor = #colorLiteral(red: 0.2729828358, green: 0.3263296783, blue: 0.3689593077, alpha: 1)
        lineChart.xAxis.axisLineColor = #colorLiteral(red: 0.2729828358, green: 0.3263296783, blue: 0.3689593077, alpha: 1)
        lineChart.xAxis.labelTextColor = #colorLiteral(red: 0.2729828358, green: 0.3263296783, blue: 0.3689593077, alpha: 1)
        lineChart.xAxis.gridColor = #colorLiteral(red: 0.2729828358, green: 0.3263296783, blue: 0.3689593077, alpha: 1)
        lineChart.rightYAxisRenderer.axis?.axisLineColor = #colorLiteral(red: 0.2729828358, green: 0.3263296783, blue: 0.3689593077, alpha: 1)
        lineChart.leftAxis.axisLineColor = #colorLiteral(red: 0.2729828358, green: 0.3263296783, blue: 0.3689593077, alpha: 1)
        lineChart.leftAxis.labelTextColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        lineChart.rightAxis.labelTextColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        lineChart.data?.setValueTextColor(#colorLiteral(red: 1, green: 1, blue: 1, alpha: 1))
        //lineChart.xAxis.granularity = 1
        //lineChart.xAxis.labelPosition = XAxis.LabelPosition.bottom
        view.addSubview(lineChart)}
    
    func loadBarGraph(entries: Any){
        let set = BarChartDataSet(entries: (entries as! [ChartDataEntry]), label: nil)
        set.colors = ChartColorTemplates.liberty()
        let data = BarChartData(dataSet: set)
        barChart.data = data
        barChart.legend.form = Legend.Form(rawValue: 0)!
        var days = [String]()
            for i in 0..<7 {
                let lst = dataArray[i][0].split(separator: " ") // returns [2020, 02, 16]
                let d = String(Int(lst[2])!), m = String(Int(lst[1])!)
                let tempStr = dataArray[i][1].uppercased() + "\n" + m + "/" + d
                days.append(tempStr)
            }
        barChart.xAxis.valueFormatter = IndexAxisValueFormatter(values:days)
        barChart.xAxis.gridColor = #colorLiteral(red: 0.2729828358, green: 0.3263296783, blue: 0.3689593077, alpha: 1)
        barChart.xAxis.axisLineColor = #colorLiteral(red: 0.2729828358, green: 0.3263296783, blue: 0.3689593077, alpha: 1)
        barChart.xAxis.labelTextColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        barChart.rightYAxisRenderer.axis?.axisLineColor = #colorLiteral(red: 0.2729828358, green: 0.3263296783, blue: 0.3689593077, alpha: 1)
        barChart.leftAxis.axisLineColor = #colorLiteral(red: 0.2729828358, green: 0.3263296783, blue: 0.3689593077, alpha: 1)
        barChart.leftAxis.labelTextColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        barChart.rightAxis.labelTextColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        barChart.data?.setValueTextColor(#colorLiteral(red: 1, green: 1, blue: 1, alpha: 1))
        barChart.xAxis.granularity = 1
        barChart.xAxis.labelPosition = XAxis.LabelPosition.bottom
        view.addSubview(barChart)
    }
    
    @IBAction func AddData(_ sender: Any) {
        // can be used for sending data to DataViewControll
    }
}// class closing bracket



//################## FUNCTIONS NOT PART OF CLASS #########################
// converting date string from user input array to readable/formated date for label
func toDate(str: String) -> String {
    let lst = str.split(separator: " ") // returns [2020, 02, 16]
    switch lst[1] {
    case "01": return "\t J A N   \((lst[2][0])) \(lst[2][1]),   \(lst[0][0]) \(lst[0][1]) \(lst[0][2]) \(lst[0][3])"
    case "02": return "\t F E B   \((lst[2][0])) \(lst[2][1]),   \(lst[0][0]) \(lst[0][1]) \(lst[0][2]) \(lst[0][3])"
    case "03": return "\t M A R   \((lst[2][0])) \(lst[2][1]),   \(lst[0][0]) \(lst[0][1]) \(lst[0][2]) \(lst[0][3])"
    case "04": return "\t A P R   \((lst[2][0])) \(lst[2][1]),   \(lst[0][0]) \(lst[0][1]) \(lst[0][2]) \(lst[0][3])"
    case "05": return "\t M A Y   \((lst[2][0])) \(lst[2][1]),   \(lst[0][0]) \(lst[0][1]) \(lst[0][2]) \(lst[0][3])"
    case "06": return "\t J U N   \((lst[2][0])) \(lst[2][1]),   \(lst[0][0]) \(lst[0][1]) \(lst[0][2]) \(lst[0][3])"
    case "07": return "\t J U L   \((lst[2][0])) \(lst[2][1]),   \(lst[0][0]) \(lst[0][1]) \(lst[0][2]) \(lst[0][3])"
    case "08": return "\t A U G   \((lst[2][0])) \(lst[2][1]),   \(lst[0][0]) \(lst[0][1]) \(lst[0][2]) \(lst[0][3])"
    case "09": return "\t S E P   \((lst[2][0])) \(lst[2][1]),   \(lst[0][0]) \(lst[0][1]) \(lst[0][2]) \(lst[0][3])"
    case "10": return "\t O C T   \((lst[2][0])) \(lst[2][1]),   \(lst[0][0]) \(lst[0][1]) \(lst[0][2]) \(lst[0][3])"
    case "11": return "\t N O V   \((lst[2][0])) \(lst[2][1]),   \(lst[0][0]) \(lst[0][1]) \(lst[0][2]) \(lst[0][3])"
    case "12": return "\t D E C   \((lst[2][0])) \(lst[2][1]),   \(lst[0][0]) \(lst[0][1]) \(lst[0][2]) \(lst[0][3])"
    default: return ""
    }
}

// for making labels appear/disappear between different seg control cases
func updateDate(label: UILabel!, s: String) {
    label.text = toDate(str: s)
    label.font = UIFont(name: "Galvji", size: CGFloat(17))
    label.textColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
    label.backgroundColor = #colorLiteral(red: 0.3979507089, green: 0.4957387447, blue: 0.563734591, alpha: 1)
}
func updateTableLabel(label: UILabel!){
    label.text = "H O U R S   S L E P T"
    label.font = UIFont(name: "Galvji", size: CGFloat(17))
    label.textColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
    label.backgroundColor = #colorLiteral(red: 0.3979507089, green: 0.4957387447, blue: 0.563734591, alpha: 1)
    label.textAlignment = NSTextAlignment.center
    label.numberOfLines = 1
    label.frame = CGRect(x: CGFloat(187), y: CGFloat(477), width: CGFloat(227), height: CGFloat(31))
}
func removeLabel(label: UILabel!){
    label.text = "  "
    label.backgroundColor = #colorLiteral(red: 0.2729828358, green: 0.3263296783, blue: 0.3689593077, alpha: 1)
}
func LabelToDailyOverview(label:UILabel!){
    label.text = "O V E R V I E W"
    label.font = UIFont(name: "Galvji", size: CGFloat(17))
    label.textColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
    label.backgroundColor = #colorLiteral(red: 0.3979507089, green: 0.4957387447, blue: 0.563734591, alpha: 1)
    label.textAlignment = NSTextAlignment.center
    label.numberOfLines = 1
    label.frame = CGRect(x: CGFloat(0), y: CGFloat(477), width: CGFloat(227), height: CGFloat(31))
}
func promptAnalysisForNoData(str: String, label: UILabel!){
    label.text = "N O    D A T A\nA V A L I A B L E\nF O R    \(str)"
    label.textColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
    //label.frame = CGRect(x: CGFloat(0), y: CGFloat(320), width: CGFloat(414), height: CGFloat(250))
    label.numberOfLines = 3
    label.textAlignment = NSTextAlignment.center
    label.backgroundColor = #colorLiteral(red: 0.2185979784, green: 0.2874768376, blue: 0.3298596144, alpha: 1)
    //label.backgroundColor = #colorLiteral(red: 0.2729828358, green: 0.3263296783, blue: 0.3689593077, alpha: 1)
}

func showImageView(image: UIImageView!){
    image.isHidden = false
}

func removeImageView(image: UIImageView!){
    image.isHidden = true
}
// for indexing String
extension StringProtocol {
    subscript(offset: Int) -> Character {
        self[index(startIndex, offsetBy: offset)]
    }
}
func getTodayWeekDay()-> String{
    let dateFormatter = DateFormatter()
    dateFormatter.dateFormat = "E"
    let weekDay = dateFormatter.string(from: Date())
    return weekDay
  }
func checkDateinArr(str: String,arr:[[String]])->Bool{
    var dateInArr = false
    for entry in arr{
        if str == entry[0]{
            dateInArr = true
        }
    }
    return dateInArr
}
extension Date {
    func isInSevenDays() -> Bool {
        let now = Date()
        let calendar = Calendar.current
        let weekday = calendar.dateComponents([.weekday], from: now)
        let startDate = calendar.startOfDay(for: now)
        let nextWeekday = calendar.nextDate(after: now, matching: weekday, matchingPolicy: .nextTime)!
        let endDate = calendar.date(byAdding: .day, value: 1, to: nextWeekday)!
        return self >= startDate && self < endDate
    }
}
func reformatToDate(strDate: String) -> Date{
    let dateFormatter = DateFormatter()
    dateFormatter.dateFormat = "yyyy MM dd"
    let date = dateFormatter.date(from: strDate)!
    return date
}
