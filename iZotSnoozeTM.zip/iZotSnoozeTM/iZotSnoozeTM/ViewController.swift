//
//  ViewController.swift
//  iZotSnoozeTM
//
//  Created by Jasmine Som on 2/5/21.
//

import UIKit
import Charts
//import SwiftUI

class ViewController: UIViewController, ChartViewDelegate, UINavigationControllerDelegate {
    
    var lineChart = LineChartView()
    var barChart = BarChartView()
    var pieChart = PieChartView()
    // data Array -> user input [date, dayOfWeek, sleepTime, wakeTime, timeDiff in sec, mood]
    var dataArray:[[String]] = [["2021 02 07", "Sun", "20:31", "10:05", "48840", "6.9"],
                                ["2021 02 06", "Sat", "21:01", "09:05", "43440", "7.6"],
                                ["2021 02 05", "Fri", "22:02", "08:15", "36780", "8.9"],
                                ["2021 02 04", "Thu", "23:01", "11:05", "43440", "5.6"],
                                ["2021 02 03", "Wed", "00:49", "10:04", "33300", "3.2"],
                                ["2021 02 02", "Tue", "20:43", "09:30", "46020", "8.3"],
                                ["2021 02 01", "Mon", "22:22", "07:41", "33540", "6.4"]]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        barChart.delegate = self
        pieChart.delegate = self
        lineChart.delegate = self
        // Do any additional setup after loading the view.
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        // setting up size and fram of charts
        barChart.frame = CGRect(x:0, y:0, width: self.view.frame.size.width, height: 250)
        pieChart.frame = CGRect(x:0, y:0, width: 300, height: 250)
        lineChart.frame = CGRect(x:0, y:0, width: self.view.frame.size.width, height: 250)
        barChart.center = CGPoint(x: 207, y: 350)
        pieChart.center = CGPoint(x: 243, y: 350)
        lineChart.center = CGPoint(x: 207, y: 350)
        self.navigationController?.isNavigationBarHidden = true
        // load default graphs upon opening
        ChangeSegControl(MultipleCharts.selectedSegmentIndex)
    }
    
    
    @IBOutlet weak var TableLabel: UILabel!
    @IBOutlet weak var MultipleCharts: UISegmentedControl!
    @IBOutlet weak var TodayDate: UILabel!
    
    // seg control
    @IBAction func ChangeSegControl(_ sender: Any) {
        switch MultipleCharts.selectedSegmentIndex
            {
            case 0: // "TODAY"
                removeTableLabel(label: TableLabel)
                barChart.removeFromSuperview()
                lineChart.removeFromSuperview()
                var entries = [ChartDataEntry]()
                //if dataArray.count >= 1 {
                    entries.append(ChartDataEntry(x: Double(0), y: Double(dataArray[0][4])!/60/60))
                    entries.append(ChartDataEntry(x: Double(1), y: (Double(24) - (Double(dataArray[0][4])!/60/60))))
                    
                    let set = PieChartDataSet(entries: entries)
                    set.colors = ChartColorTemplates.liberty()
                    
                    let data = PieChartData(dataSet: set)
                    pieChart.data = data
                    pieChart.data?.setValueFont(NSUIFont.systemFont(ofSize: 0))
                    pieChart.holeRadiusPercent = CGFloat(0)
                    pieChart.centerTextRadiusPercent = CGFloat(1)
                    pieChart.legend.entries = [LegendEntry(label: "SLEPT  ", form: .default, formSize: CGFloat(20), formLineWidth: CGFloat(30), formLineDashPhase: .nan, formLineDashLengths: .none, formColor: #colorLiteral(red: 0.5796257854, green: 0.8301811218, blue: 0.8309018612, alpha: 1)), LegendEntry(label: "AWAKE  ", form: .default, formSize: CGFloat(20), formLineWidth: CGFloat(30), formLineDashPhase: .nan, formLineDashLengths: .none, formColor: #colorLiteral(red: 0.812982142, green: 0.9734575152, blue: 0.9664494395, alpha: 1))]
                    pieChart.legend.yEntrySpace = CGFloat(10)
                    pieChart.legend.xEntrySpace = CGFloat(70)
                    pieChart.legend.form = Legend.Form(rawValue: 4)!
                    pieChart.legend.horizontalAlignment = Legend.HorizontalAlignment(rawValue: 0)!
                    pieChart.legend.verticalAlignment = Legend.VerticalAlignment(rawValue: 1)!
                    pieChart.legend.orientation = Legend.Orientation(rawValue: 1)!
                    pieChart.legend.textWidthMax = CGFloat(70)
                    pieChart.legend.font = NSUIFont.systemFont(ofSize: 12.0)
                    pieChart.legend.textColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
                    pieChart.transparentCircleColor = #colorLiteral(red: 0.2729828358, green: 0.3263296783, blue: 0.3689593077, alpha: 1)
                    updateDate(label: TodayDate, s: dataArray[0][0])
                    view.addSubview(pieChart)
                //}
        
        
            case 1: // "WEEK"
                updateTableLabel(label: TableLabel)
                removeDate(label: TodayDate)
                pieChart.removeFromSuperview()
                lineChart.removeFromSuperview()
                var entries = [BarChartDataEntry]()
                //if dataArray.count >= 7 {
                    for i in 0..<7 {
                        entries.append(BarChartDataEntry(x: Double(i+1), y: Double(dataArray[i][4])!/60/60))
                    }
                    loadBarGraph(entries: entries)
                /*} else {
                    for i in 0..<dataArray.count {
                        entries.append(BarChartDataEntry(x: Double(i+1), y: Double(dataArray[i][4])!/60/60))
                    }
                    loadBarGraph(entries: entries)
                }*/
                // should load empty data to have chart correctly initialized
        
        
            case 2: // "MONTH"
                updateTableLabel(label: TableLabel)
                barChart.removeFromSuperview()
                removeDate(label: TodayDate)
                pieChart.removeFromSuperview()
                var entries = [ChartDataEntry]()
                dataArray.sort{($0[0] < $1[0])}
                // need to set x to == day of the month
                // use calendar to sync and show based on user month
                if dataArray.count >= 30 {
                    for i in 0..<30 {
                        entries.append(ChartDataEntry(x: Double(i), y: Double(dataArray[i][4])!/60/60))
                    }
                    loadlineGraph(entries: entries)
                } else {
                    for i in 0..<dataArray.count {
                        entries.append(ChartDataEntry(x: Double(i), y: Double(dataArray[i][4])!/60/60))
                    }
                    loadlineGraph(entries: entries)}
                dataArray.sort{($0[0] > $1[0])}
        case 3: // "TIPS"
            removeTableLabel(label: TableLabel)
            removeDate(label: TodayDate)
            pieChart.removeFromSuperview()
            lineChart.removeFromSuperview()
            barChart.removeFromSuperview()
        default:
            break
        }
    }
    
    @IBAction func AddData(_ sender: Any) {
        // can be used for sending data to DataViewControll
    }

    func loadlineGraph(entries: Any){
        let set = LineChartDataSet(entries: (entries as! [ChartDataEntry]), label: nil)
        set.colors = ChartColorTemplates.liberty()
        let data = LineChartData(dataSet: set)
        lineChart.data = data
        lineChart.legend.form = Legend.Form(rawValue: 0)!
        //lineChart.xAxis.gridColor = #colorLiteral(red: 0.2729828358, green: 0.3263296783, blue: 0.3689593077, alpha: 1)
        lineChart.xAxis.axisLineColor = #colorLiteral(red: 0.2729828358, green: 0.3263296783, blue: 0.3689593077, alpha: 1)
        lineChart.xAxis.labelTextColor = #colorLiteral(red: 0.2729828358, green: 0.3263296783, blue: 0.3689593077, alpha: 1)
        lineChart.xAxis.gridColor = #colorLiteral(red: 0.2729828358, green: 0.3263296783, blue: 0.3689593077, alpha: 1)
        lineChart.rightYAxisRenderer.axis?.axisLineColor = #colorLiteral(red: 0.2729828358, green: 0.3263296783, blue: 0.3689593077, alpha: 1)
        lineChart.leftAxis.axisLineColor = #colorLiteral(red: 0.2729828358, green: 0.3263296783, blue: 0.3689593077, alpha: 1)
        lineChart.leftAxis.labelTextColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        lineChart.rightAxis.labelTextColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        lineChart.data?.setValueTextColor(#colorLiteral(red: 1, green: 1, blue: 1, alpha: 1))
        //lineChart.xAxis.granularity = 1
        //lineChart.xAxis.labelPosition = XAxis.LabelPosition.bottom
        view.addSubview(lineChart)}
    
    func loadBarGraph(entries: Any){
        let set = BarChartDataSet(entries: (entries as! [ChartDataEntry]), label: nil)
        set.colors = ChartColorTemplates.liberty()
        let data = BarChartData(dataSet: set)
        barChart.data = data
        barChart.legend.form = Legend.Form(rawValue: 0)!
        var days = [""]
        for i in 0..<7 {
            let lst = dataArray[i][0].split(separator: " ") // returns [2020, 02, 16]
            let d = String(Int(lst[2])!), m = String(Int(lst[1])!)
            let tempStr = dataArray[i][1].uppercased() + "\n" + m + "/" + d
            days.append(tempStr)
        }
        //let days = ["", dataArray[0][1].uppercased(), dataArray[1][1].uppercased(), dataArray[2][1].uppercased(), dataArray[3][1].uppercased(), dataArray[4][1].uppercased(), dataArray[5][1].uppercased(), dataArray[6][1].uppercased()]
        barChart.xAxis.valueFormatter = IndexAxisValueFormatter(values:days)
        barChart.xAxis.gridColor = #colorLiteral(red: 0.2729828358, green: 0.3263296783, blue: 0.3689593077, alpha: 1)
        barChart.xAxis.axisLineColor = #colorLiteral(red: 0.2729828358, green: 0.3263296783, blue: 0.3689593077, alpha: 1)
        barChart.xAxis.labelTextColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        barChart.rightYAxisRenderer.axis?.axisLineColor = #colorLiteral(red: 0.2729828358, green: 0.3263296783, blue: 0.3689593077, alpha: 1)
        barChart.leftAxis.axisLineColor = #colorLiteral(red: 0.2729828358, green: 0.3263296783, blue: 0.3689593077, alpha: 1)
        barChart.leftAxis.labelTextColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        barChart.rightAxis.labelTextColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        barChart.data?.setValueTextColor(#colorLiteral(red: 1, green: 1, blue: 1, alpha: 1))
        barChart.xAxis.granularity = 1
        barChart.xAxis.labelPosition = XAxis.LabelPosition.bottom
        view.addSubview(barChart)
    }
}

// converting date string from user input array to readable/formated date for label
func toDate(str: String) -> String {
    let lst = str.split(separator: " ") // returns [2020, 02, 16]
    switch lst[1] {
    case "01": return "    J A N   \((lst[2][0])) \(lst[2][1]),   \(lst[0][0]) \(lst[0][1]) \(lst[0][2]) \(lst[0][3])"
    case "02": return "    F E B   \((lst[2][0])) \(lst[2][1]),   \(lst[0][0]) \(lst[0][1]) \(lst[0][2]) \(lst[0][3])"
    case "03": return "    M A R   \((lst[2][0])) \(lst[2][1]),   \(lst[0][0]) \(lst[0][1]) \(lst[0][2]) \(lst[0][3])"
    case "04": return "    A P R   \((lst[2][0])) \(lst[2][1]),   \(lst[0][0]) \(lst[0][1]) \(lst[0][2]) \(lst[0][3])"
    case "05": return "    M A Y   \((lst[2][0])) \(lst[2][1]),   \(lst[0][0]) \(lst[0][1]) \(lst[0][2]) \(lst[0][3])"
    case "06": return "    J U N   \((lst[2][0])) \(lst[2][1]),   \(lst[0][0]) \(lst[0][1]) \(lst[0][2]) \(lst[0][3])"
    case "07": return "    J U L   \((lst[2][0])) \(lst[2][1]),   \(lst[0][0]) \(lst[0][1]) \(lst[0][2]) \(lst[0][3])"
    case "08": return "    A U G   \((lst[2][0])) \(lst[2][1]),   \(lst[0][0]) \(lst[0][1]) \(lst[0][2]) \(lst[0][3])"
    case "09": return "    S E P   \((lst[2][0])) \(lst[2][1]),   \(lst[0][0]) \(lst[0][1]) \(lst[0][2]) \(lst[0][3])"
    case "10": return "    O C T   \((lst[2][0])) \(lst[2][1]),   \(lst[0][0]) \(lst[0][1]) \(lst[0][2]) \(lst[0][3])"
    case "11": return "    N O V   \((lst[2][0])) \(lst[2][1]),   \(lst[0][0]) \(lst[0][1]) \(lst[0][2]) \(lst[0][3])"
    case "12": return "    D E C   \((lst[2][0])) \(lst[2][1]),   \(lst[0][0]) \(lst[0][1]) \(lst[0][2]) \(lst[0][3])"
    default: return ""
    }
}

// for making labels appear/disappear between different seg control cases
func updateDate(label: UILabel!, s: String) {
    label.text = toDate(str: s)
    label.font = UIFont(name: "Galvji", size: CGFloat(17))
    label.textColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
    label.backgroundColor = #colorLiteral(red: 0.3979507089, green: 0.4957387447, blue: 0.563734591, alpha: 1)
}
func removeDate(label: UILabel!){
    label.text = "  "
    label.backgroundColor = #colorLiteral(red: 0.2729828358, green: 0.3263296783, blue: 0.3689593077, alpha: 1)
}
func updateTableLabel(label: UILabel!){
    label.text = "     H O U R S   S L E P T"
    label.font = UIFont(name: "Galvji", size: CGFloat(17))
    label.textColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
    label.backgroundColor = #colorLiteral(red: 0.3979507089, green: 0.4957387447, blue: 0.563734591, alpha: 1)
}
func removeTableLabel(label: UILabel!){
    label.text = "  "
    label.backgroundColor = #colorLiteral(red: 0.2729828358, green: 0.3263296783, blue: 0.3689593077, alpha: 1)
}

// for indexing String
extension StringProtocol {
    subscript(offset: Int) -> Character {
        self[index(startIndex, offsetBy: offset)]
    }
}


