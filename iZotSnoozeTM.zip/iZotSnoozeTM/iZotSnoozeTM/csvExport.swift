//
//  csvExport.swift
//  iZotSnoozeTM
//
//  Created by Jasmine Som on 3/1/21.
//

import Foundation

// MARK: CSV file creating
/*func creatCSV() -> Void {
    let taskArr = [String]()
    let fileName = "Tasks.csv"
    let path = NSURL(fileURLWithPath: NSTemporaryDirectory()).appendingPathComponent(fileName)
    var csvText = "Date,Task Name,Time Started,Time Ended\n"

    for task in taskArr {
        let newLine = "\(task.date),\(task.name),\(task.startTime),\(task.endTime)\n"
        csvText.append(newLine)
    }

    do {
        try csvText.write(to: path!, atomically: true, encoding: String.Encoding.utf8)
    } catch {
        print("Failed to create file")
        print("\(error)")
    }
    print(path ?? "not found")
}*/

