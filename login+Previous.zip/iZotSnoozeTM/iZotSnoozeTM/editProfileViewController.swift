//
//  editProfileViewController.swift
//  iZotSnoozeTM
//
//  Created by Kayla Hoang on 3/8/21.
//

import UIKit

class editProfileViewController: UIViewController {

    @IBOutlet var nameField: UITextField!
    var nameText = String()
    public var completionHandler: ((String?) -> Void)?
    override func viewDidLoad() {
        super.viewDidLoad()
        nameField.text = nameText
        // Do any additional setup after loading the view.
    }
    
    @IBAction func saveTapped(){
        //create property that the first view controller can find; calls fcn before dismissing
        completionHandler?(nameField.text)
        dismiss(animated: true, completion: nil)
    }
    

}
