//
//  ProfileViewController.swift
//  iZotSnoozeTM
//
//  Created by Jasmine Som on 3/2/21.
//

import Foundation
import UIKit

class ProfileViewController : UIViewController, UIImagePickerControllerDelegate & UINavigationControllerDelegate {
    
    @IBOutlet var nameDisplay: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.isNavigationBarHidden = false
    }
    
    @IBAction func backTapped(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(identifier: "menu") 
        vc.modalPresentationStyle = .fullScreen
        present(vc,animated:true)
    }
    
    @IBAction func editTapped(){
        let vc = storyboard?.instantiateViewController(identifier: "edit") as! editProfileViewController
        vc.modalPresentationStyle = .fullScreen
        //before presenting controller get text back from closure
        vc.completionHandler = { text in
            self.nameDisplay.text = text
        }
        present(vc,animated:true)
    }
    /*func takePhoto(sender: AnyObject) {
        if (UIImagePickerController.isSourceTypeAvailable(UIImagePickerController.SourceType.camera)){
            var picker = UIImagePickerController()
            picker.delegate = self
            picker.sourceType = UIImagePickerController.SourceType.camera
            var mediaTypes: Array<AnyObject> = [UIImageAsset]
            picker.mediaTypes = mediaTypes
            picker.allowsEditing = true
            self.present(picker, animated: true, completion: nil)
        }
        else{
            NSLog("No Camera.")
        }
    }

    func imagePickerController(picker: UIImagePickerController!, didFinishPickingImage image: UIImage!, editingInfo: NSDictionary!) {
        let selectedImage : UIImage = image
    }*/
}
