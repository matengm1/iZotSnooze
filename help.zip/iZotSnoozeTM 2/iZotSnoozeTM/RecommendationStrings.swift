//
//  RecommendationStrings.swift
//  iZotSnoozeTM
//
//  Created by Jasmine Som on 3/3/21.
//

import Foundation

class RecommendationString{
    
    let string0 =
        """
        Your average hours slept has decreased
        by [] hours and averaging [] hours over
        the past month. We recommend adjusting
        your schedule to sleep between the
        hours of 8PM and midnight for optimum
        sleep.
        """
    let string1 =
        """
        You slept [] hours last night. Based on
        your recorded mood, we recommend
        improving your quality of sleep by
        trying the following:
            - Increase bright light exposure
              during the day.
            - Reduce blue light exposure in
              the evening.
            - Don’t consume caffeine late in
              the day.
            - Reduce irregular or long daytime
              naps.
            - Try to sleep and wake at
              consistent times.
            - Consider taking supplements
              including: melatonin, ginkgo
              biloba, glycine, valerian root,
              magnesium, l-theanine, and
              lavender supplements.
              Make sure to only try these
              supplements ONE at a time.
            - Don’t drink alcohol as it
              decreases the natural nighttime
              elevations in human growth
              hormone and alters your
              nighttime melatonin production,
              which both play a role in your
              circadian rhythm.
            - Optimize your bedroom environment
              like adjusting noise, external
              lights, and furniture
              arrangement.
            - Set your bedroom temperature to
              around 70°F (20°C)
            - Don’t eat late in the evening as
              it may negatively affect both
              sleep quality and the natural
              release of your human growth
              hormone and melatonin.
            - Relax and clear your mind in the
              evening with strategies like
              listening to relaxing music,
              reading a book, taking a hot
              bath, meditating, deep
              breathing, and visualization.
            - Take a relaxing bath or shower
              about 90 minutes or simply soak
              your feet in hot water before
              you sleep
            - Get a comfortable bed, mattress,
              and pillow. We recommended that
              you upgrade your bedding at
              least every 5–8 years.
            - Exercise regularly — but not
              before bed
            - Don’t drink any liquids before
              bed and using the bathroom
              before bed
        """
    let string2 =
        """
        Recomendation 2 jroinw ehtwoen rphqurh
        nihw woh olaj ihero nwheow i ew iew
        eiheoh oe nfiewof.
        """
    let string3 =
        """
        Recommendation 3 hfsoun efiwjioe
        nwjohewoughwuherouewhn oewhoih ewoihot
        iwehtoinew oithewohoiweh ohoewi
        hroiwehow.
        """
    let string4 =
        """
        Recommendation 4 owih neowht
        oweljr owihtoelwj ntpheoithewp how
        iehn toewh wehour nwohew ohwe ih oie.
        """
    let string5 =
        """
        Recomendation 5 jroinw ehtwoen
        rphqurh nihw woh olaj ihero nwheow i
        ew ie eiheoh oe nfiewof.
        """
}
