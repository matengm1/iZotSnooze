//
//  ProfileViewController.swift
//  iZotSnoozeTM
//
//  Created by Jasmine Som on 3/2/21.
//

import Foundation
import UIKit

class ProfileViewController : UIViewController, UIImagePickerControllerDelegate & UINavigationControllerDelegate {
    
    @IBOutlet var nameDisplay: UILabel!
    @IBOutlet var ageDisplay: UILabel!
    @IBOutlet var weightDisplay: UILabel!
    @IBOutlet var heightDisplay: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.isNavigationBarHidden = false
        if UserDefaults.standard.object(forKey: "getName") != nil {
            self.nameDisplay.text = UserDefaults.standard.string(forKey: "getName")
        }
        if UserDefaults.standard.object(forKey: "getAge") != nil {
            self.ageDisplay.text = UserDefaults.standard.string(forKey: "getAge")
        }
        if UserDefaults.standard.object(forKey: "getWeight") != nil {
            self.weightDisplay.text = UserDefaults.standard.string(forKey: "getWeight")
        }
        if UserDefaults.standard.object(forKey: "getHeight") != nil {
            self.heightDisplay.text = UserDefaults.standard.string(forKey: "getHeight")
        }
        
    }
    
    @IBAction func backTapped(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(identifier: "menu") 
        vc.modalPresentationStyle = .fullScreen
        present(vc,animated:true)
    }
    
    @IBAction func editTapped(){
        let vc = storyboard?.instantiateViewController(identifier: "edit") as! editProfileViewController
        vc.modalPresentationStyle = .fullScreen
        //before presenting controller get text back from closure
        vc.completionHandler = { text,age,weight,height in
            self.nameDisplay.text = text
            self.ageDisplay.text = age
            self.weightDisplay.text = weight
            self.heightDisplay.text = height
            UserDefaults.standard.set(text,forKey:"getName")
            UserDefaults.standard.set(age,forKey:"getAge")
            UserDefaults.standard.set(weight,forKey:"getWeight")
            UserDefaults.standard.set(height,forKey:"getHeight")
            
        }
        present(vc,animated:true)
    }
    /*func takePhoto(sender: AnyObject) {
        if (UIImagePickerController.isSourceTypeAvailable(UIImagePickerController.SourceType.camera)){
            var picker = UIImagePickerController()
            picker.delegate = self
            picker.sourceType = UIImagePickerController.SourceType.camera
            var mediaTypes: Array<AnyObject> = [UIImageAsset]
            picker.mediaTypes = mediaTypes
            picker.allowsEditing = true
            self.present(picker, animated: true, completion: nil)
        }
        else{
            NSLog("No Camera.")
        }
    }

    func imagePickerController(picker: UIImagePickerController!, didFinishPickingImage image: UIImage!, editingInfo: NSDictionary!) {
        let selectedImage : UIImage = image
    }*/
}
