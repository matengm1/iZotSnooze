//
//  SleepData+CoreDataClass.swift
//  
//
//  Created by Gerald Post  on 3/7/21.
//
//

import Foundation
import CoreData

//@objc(SleepData)
public class SleepData: NSManagedObject {

}
