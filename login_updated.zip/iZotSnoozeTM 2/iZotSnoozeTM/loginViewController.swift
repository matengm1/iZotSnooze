//
//  loginViewController.swift
//  iZotSnoozeTM
//
//  Created by Kayla Hoang on 3/8/21.
//

import UIKit
import Firebase
import FirebaseAuth

class loginViewController: UIViewController {

    @IBOutlet var email: UITextField!
    @IBOutlet var password: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
//        if Auth.auth().currentUser?.uid != nil {
//            handleLogout()
//        }
        // Do any additional setup after loading the view.
        
        Auth.auth().addStateDidChangeListener { auth, user in
                if user != nil{
                    // User is signed in.
                    print("User is not logged out.")
                    let sb = UIStoryboard(name:"Main", bundle: nil)
                    let vc = sb.instantiateViewController(withIdentifier: "menu")
                    vc.modalPresentationStyle = .overFullScreen
                    self.present(vc,animated:true)
                } else {
                    // No user is signed in.
                    print("No user is signed in.")
                }
            }
    }
    
//    override func viewDidAppear(_ animated: Bool) {
//        checkInfo()
//    }
//    func handleLogout(){
//        do{
//
//        }
//        let loginController = loginViewController()
//        present(loginController,animated:true,completion:nil)
//    }

    @IBAction func loginTapped(_ sender: Any) {
        validateFields()
    }
    
    func validateFields(){
        // validates if user enters both fields
        if email.text?.isEmpty == true {
            print("Email missing")
            return
        }
        if password.text?.isEmpty == true {
            print("password missing")
            return
        }
        login()
    }
    
    func login(){
        //unwrap to prevent crashing
        Auth.auth().signIn(withEmail: email.text!, password: password.text!) { [weak self] aResult, err in
            //print(aResult)
            guard self != nil else{return}
            if let err = err {
                print(err.localizedDescription)
            }
            //if login successfull then checks information
            self!.checkInfo()
        }
    }
    
    func checkInfo(){
        //checks user info after logging in
        //verify if therte's a current user and print id if so
        if Auth.auth().currentUser != nil {
            //UserDefaults.standard.set(value)
            //print(Auth.auth().currentUser?.uid)
            let sb = UIStoryboard(name: "Main",bundle:nil)
            let vc = sb.instantiateViewController(withIdentifier: "menu")
            vc.modalPresentationStyle = .overFullScreen
            present(vc,animated:true)
        }
    }
    
    @IBAction func signUpTapped(_ sender: Any) {
        //create account nvigate to signup screen
        let sb = UIStoryboard(name: "Main",bundle:nil)
        let vc = sb.instantiateViewController(withIdentifier: "sign")
        vc.modalPresentationStyle = .overFullScreen
        present(vc,animated:true)
    }
    
}
