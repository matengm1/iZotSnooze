
import UIKit
import FirebaseAuth

class LoginViewController: UIViewController {

    @IBOutlet var email: UITextField!
    @IBOutlet var password: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    @IBAction func LoginTapped(_ sender: Any) {
        validateFields()
        
    }
    @IBAction func CreateTapped(_ sender: Any) {
        //create account nvigate to signup screen
        let sb = UIStoryboard(name: "Main",bundle:nil)
        //view to show; add id 'su' to signup
        let vc = sb.instantiateViewController(withIdentifier: "su")
        vc.modalPresentationStyle = .overFullScreen
        //show the view controller
        present(vc,animated:true)
    }
    
    func validateFields(){
        // validates if user enters both fields
        if email.text?.isEmpty == true {
            print("Email missing")
            return
        }
        if password.text?.isEmpty == true {
            print("password missing")
            return
        }
        login()
    }
    func login(){
        //unwrap to prevent crashing
        Auth.auth().signIn(withEmail: email.text!, password: password.text!) { [weak self] aResult, error in
            guard let strongerSelf = self else{return}
            if let error = error {
                print(error.localizedDescription)
            }
            //if login successfull then checks information
            self!.checkInfo()
        }
    }
    func checkInfo(){
        //checks user info after logging in
        //verify if therte's a current user and print id if so
        if Auth.auth().currentUser != nil {
            print(Auth.auth().currentUser?.uid)
            let sb = UIStoryboard(name:"Main", bundle: nil)
            let vc = sb.instantiateViewController(withIdentifier: "mainScreen")
            vc.modalPresentationStyle = .overFullScreen
            present(vc,animated:true)
        }
    }
}
