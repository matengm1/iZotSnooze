//
//  RecommendationStrings.swift
//  iZotSnoozeTM
//
//  Created by Jasmine Som on 3/3/21.
//

import Foundation

class RecommendationString{
    
    let string0 =
        """
        Recommendation 0 hfsoun skjd jksd
        efiwjioe
        nwjohewoughwuherouewhn
        oewhoih ewoihot
        iwehtoinew
        oithewohoiweh ohoewi
        hroiwehow.
        """
    let string1 =
        """
        Recommendation 1 owih neowht
        oweljr owihtoelwj
        ntpheoithewp how
        iehn toewhr wehour
        nwohew ohwe ih oie.
        """
    let string2 =
        """
        Recomendation 2 jroinw
        ehtwoen
        rphqurh nihw woh
        olaj ihero nwheow i
        ew iew
        eiheoh oe nfiewof.
        """
    let string3 =
        """
        Recommendation 3 hfsoun efiwjioe
        nwjohewoughwuherouewhn oewhoih ewoihot
        iwehtoinew
        oithewohoiweh ohoewi hroiwehow.
        """
    let string4 =
        """
        Recommendation 4 owih neowht
        oweljr owihtoelwj ntpheoithewp how iehn toewhr
        wehour
        nwohew ohwe ih oie.
        """
    let string5 =
        """
        Recomendation 5 jroinw ehtwoen
        rphqurh nihw woh olaj ihero nwheow i
        ew ie eiheoh oe nfiewof.
        """
}
