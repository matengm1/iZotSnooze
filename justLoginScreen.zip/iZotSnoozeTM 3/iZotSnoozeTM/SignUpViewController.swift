

import UIKit
import FirebaseAuth
import Firebase
class SignUpViewController: UIViewController {

    @IBOutlet var email: UITextField!
    @IBOutlet var password: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func returnHome(_ sender: Any) {
        //code to just go back to login screen
        let storyb = UIStoryboard(name:"Main", bundle: nil)
        let vc = storyb.instantiateViewController(withIdentifier: "login")
        vc.modalPresentationStyle = .overFullScreen
        present(vc,animated:true)
    }
    
    @IBAction func backToLogin(_ sender: Any) {
        //code to just go back to login screen
        let sb = UIStoryboard(name:"Main", bundle: nil)
        let vc = sb.instantiateViewController(withIdentifier: "login")
        vc.modalPresentationStyle = .overFullScreen
        present(vc,animated:true)
    }
    
    @IBAction func signUpTapped(_ sender: Any) {
        //verify user type in email and password fields
        if email.text?.isEmpty == true{
            print("email missing")
            return
        }
        if password.text?.isEmpty == true{
            print("password missing")
            return
        }
        authenticate()
    }
    

    
    func authenticate(){
        //Send information and pass word to firebase
        
        //unwrapped here in case it doesn't contain any text
        Auth.auth().createUser(withEmail: email.text!, password: password.text!) { (aResult, error) in
            // add completetion handler to verify success; check if user entered if not prints error to console
            guard let user = aResult?.user,error == nil else{
                print("error \(error?.localizedDescription)")
                return
            }
                // if successful, goes to success screen
                let storyb = UIStoryboard(name: "Main", bundle: nil)
                let viewc = storyb.instantiateViewController(withIdentifier: "success")
                viewc.modalPresentationStyle = .overFullScreen
                self.present(viewc,animated:true)// self used here cuz it's outside fcn
        }
    }
}
