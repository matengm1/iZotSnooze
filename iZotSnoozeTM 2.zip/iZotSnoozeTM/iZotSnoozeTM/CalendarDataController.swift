//
//  ViewController.swift
//  iZotSnooze
//
//  Created by Gerald Post  on 2/12/21.
//

import FSCalendar
import UIKit


class CalendarDataController: UIViewController, FSCalendarDelegate, UITableViewDelegate, UITableViewDataSource {

    var dateSelected = ""
    var dayOfWeekSelected = ""

    @IBOutlet weak var calendar: FSCalendar!
    @IBOutlet weak var tableView: UITableView!
    
    let titleArray = ["Date", "Day of the Week", "Time Slept", "Time Woke", "Time Slept in Seconds", "Mood", "Noise Ambiance", "Heartrate", "Breath Rate"]
    var dayData = ["YYYY MM dd","E","00:00", "00:00", "0", "0", "0", "0", "0","N"]
    override func viewDidLoad() {
        super.viewDidLoad()
        calendar.delegate = self
        tableView.delegate = self
        tableView.dataSource = self
        
        // Do any additional setup after loading the view.
    }
    
    // TableView funcs
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return titleArray.count
    }
   
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        let string = titleArray[indexPath.row] + ": " + dayData[indexPath.row]
        cell.textLabel?.text = string
        return cell
    }
    
    // calendar is not appearing :(
    func calendar(_ calendar: FSCalendar, didSelect date: Date, at monthPosition: FSCalendarMonthPosition) {
        let formatter = DateFormatter()
        let dayOfWeekFormatter = DateFormatter()
        formatter.dateFormat = "YYYY MM dd"
        dayOfWeekFormatter.dateFormat = "E"
        let day = dayOfWeekFormatter.string(from: date)
        let string = formatter.string(from: date)
        
        // for getting the day's data from the nested array
        dateSelected = "\(string)"
        dayOfWeekSelected = "\(day)"
        print(dateSelected)
        let mainVC = navigationController?.viewControllers.first as? ViewController
        for i in 0..<titleArray.count {
            if dateSelected == mainVC!.dataArray[i][0] {
                dayData = mainVC!.dataArray[i]
            }
        dayData = [dateSelected, dayOfWeekSelected,"00:00", "00:00", "0", "0", "0", "0", "0","N"]
        }
    }
}

